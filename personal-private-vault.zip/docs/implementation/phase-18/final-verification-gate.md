## D26 prospective CPU-only applicability - 2026-10-25

**OWNER_APPROVED scope amendment; final acceptance NOT GRANTED.** [D26](owner-decisions.md#d26-cpu-only)
selects pinned offline CPU inference ONLY. Actual CUDA inference, GPU OOM-to-CPU fallback
and process-attributed GPU VRAM remain **NOT VERIFIED** and are
**NOT_APPLICABLE_UNDER_OWNER_APPROVED_CPU_ONLY_SCOPE**, never PASS. See the
[exact execution profile and reconciliation](cpu-only-d26-applicability-2026-10-25.md).

| Focused receipt | D26 effective requirement |
| --- | --- |
| P18-OFFLINE-MODEL | Pinned model/tokenizer and verified offline CPU inference, finite correctly dimensioned vectors, bounded CPU resources and failures; actual GPU inference/fallback subcases take D26 status. |
| P18-RESOURCES | Representative final Markdown CPU producer/verifier/Java/PG RAM, CPU/wall/temp-disk, finite expansion/transport/chunk bounds, cancellation/stop/cleanup and truthful host headroom remain mandatory. GPU process-VRAM subcases alone take D26 status. |
| P18-REPORT | Preserve truthful CPU/model/device/outcome/currentness/resource/recovery reporting. Unknown/not-verified GPU values stay absent/qualified, not zero or successful fallback. |

**All five executable commands, cwd/interpreter/profile/timeout/test limits and their code block below are byte-for-byte unchanged.** Independently audited existing PASS receipts remain applicable on unchanged source: Ruff, format, mypy, full pytest 238/0/0/0 and full clean Java 1,580 testcase elements vs 1,567 suite attributes, 0 failures/errors, 1 existing ADR-0023 diagnostic skip; genuine exit 0 in 1,937.915s within 2,100s. No full Java rerun or other machine gate is launched for this documentation amendment. All applicable focused evidence and independent/Owner gates remain required before P18-FINAL acceptance.

This is prospective acceptance applicability only. Unaffected Markdown/authority/publication,
CPU/RAM/disk/deadline/cancellation/security and five-command requirements remain mandatory.
Future GPU enablement requires separate Owner authorization and independent verification.
No source/runtime/test/model/lock/runner change, activation or closeout follows. Original
GPU_EVIDENCE_BLOCKED and failed/timeout evidence remains unchanged historical truth.
Slice 4/P18-FINAL/Phase 18 remain NOT ACCEPTED / NOT CLOSED; indexing INACTIVE.

## Preserved pre-D26 text - unaffected rules remain effective

> **Java component verification - 2026-10-25: JAVA_FULL_GATE_VERIFIED.** One Owner-authorized unchanged full clean Java gate passed exit 0 in 1,937.915s, within 2,100s. Fresh counts: 1,580 testcase elements / 1,567 suite-attribute tests, 0 failures, 0 errors, 1 existing ADR-0023 opt-in alias skip. See [handback](slice-4-java-instrumented-full-gate-handback-2026-10-25.md) and [evidence](slice-4-java-instrumented-full-gate-evidence-2026-10-25.json). This verifies only the Java command; all other P18-FINAL obligations and independent adjudication remain applicable. GPU_EVIDENCE_BLOCKED, external indexing INACTIVE, Slice 4/P18-FINAL NOT ACCEPTED. Prior failed/timeout records and all executable commands below are preserved unchanged. No further execution, implementation or publishing follows.

## Preserved earlier verification records and unchanged gate contract

> **Final count qualification:** current Maven stdout1580/1/0/1; fresh XML1567/1/0/1, difference13 UNEXPLAINED. Exit1/FAILED; no P18-FINAL acceptance. See the corrective handback for both current and historical counts.

> **Corrective handback - 2026-10-24:** `BLOCKED / GPU_EVIDENCE_BLOCKED`. See [handback](slice-4-codex-corrective-handback-2026-10-24.md) and [S4 matrix](slice-4-codex-corrective-matrix-2026-10-24.md). Native 104 and Python 238 pass; actual full Java exit 1 ({'tests': 1567, 'failures': 1, 'errors': 0, 'skipped': 1}). CUDA inference/fallback remains unavailable and unwaived. Slice 4/P18-FINAL NOT ACCEPTED. Earlier dated results/statuses below are preserved history.

> **S4 executable routing ? 2026-10-23:** [ACTIVE](../handoffs/ACTIVE.md) is now `P18-S4-LIFECYCLE-FINAL / READY_FOR_IMPLEMENTATION`; [executable contract](slice-4-executable-handoff-2026-10-23.md) and [full S4 tests/resource plan](slice-4-execution-and-test-plan-2026-10-23.md). Implementation NOT_STARTED and S4 rows NOT_RUN. The five P18-FINAL commands are unchanged; historical Java aggregate FAILED, D22 NOT_RECOVERED, indexing INACTIVE and P18-FINAL NOT ACCEPTED. Older pending notices below are historical.

**CURRENT OWNER STATUS — D25 / 2026-10-23:** Phase 18 **Slice 3 Verified Indexing D+F is COMPLETE / CLOSED / OWNER-PUBLISHED** at verified GitHub `main` commit `e2e00534fb35534a298e8fb15d174f18cb63b5a0` (90/90 reviewed paths). S3-F01–F06, S3-RR-01–03 and **FR18-3 are independently VERIFIED/CLOSED** within D24's Obsidian `.md` producer → Java → PostgreSQL publication scope. Owner has authorized **Slice 4 Lifecycle & Final (E+H)**; canonical [ACTIVE](../handoffs/ACTIVE.md) now records `P18-S4-LIFECYCLE-FINAL / PENDING_CODEX_HANDOFF`. Refer to [D25](owner-decisions.md#2026-10-23--d25-slice-3-owner-published-closeout-and-slice-4-authorization), [Slice 3 closeout](slice-3-closeout-2026-10-23.md), [Slice 4 preparation](slice-4-lifecycle-final-handoff-2026-10-23.md) and [S4 matrix](slice-4-lifecycle-final-acceptance-2026-10-23.md). External indexing **INACTIVE**; live originals **DISABLED/DEFERRED**; Phase 18/P18-FINAL **NOT ACCEPTED**; historical Java full gate **FAILED**; D22 originals **NOT_RECOVERED**. Consolidated removal of unaccepted TXT/`.markdown`/PDF/Office/OCR implementation is planned **once near Slice 4 end before P18-FINAL**; historical applied Flyway migrations and failure evidence remain intact. The D24 and older status statements below are **dated historical records and do not override D25**.

---

**D24 CURRENT - 2026-10-21:** Overall Phase 18 external document target is **Obsidian Markdown `.md` ONLY**. Owner authorizes the new initial **Slice 3 Verified Indexing D+F**; see [D24](owner-decisions.md#2026-10-21--d24-overall-markdown-only-phase-18-and-slice-3-verified-indexing), [executable handoff](slice-3-verified-indexing-handoff.md), [baseline/applicability/cleanup](slice-3-markdown-scope-and-baseline-2026-10-21.md). Slice 2/D23 producer-local scope is CLOSED and prior work is **published** at verified main `ef32d41b33dd00e5fa08cf63977e91b8936ef3d5`, including unaccepted mixed changes; publication does not accept them. The former selective staging/commit workflow is superseded and must not be reopened. TXT/Office/PDF/OCR are excluded from Slice 3 and final Markdown acceptance; temporarily retain without use/certification, then remove unnecessary implementation/dependencies/tests/fixtures once at Slice 4 end before P18-FINAL. No Slice 4 implementation now. Phase 17 FROZEN; Slice 1/D14 CLOSED; D22 originals NOT_RECOVERED / original preservation FAILED; FR18-3 OPEN; Java publication NOT ACCEPTED; historical full Java gate FAILED until genuine successful rerun; indexing INACTIVE; live originals DISABLED/DEFERRED; P18-FINAL NOT ACCEPTED. Historical Antigravity remediation 2/2 remains exhausted; this initial slice grants no extra remediation rounds. Preparation only in this session; no activation or agent publishing.

## D24 effective final-gate applicability

The final five-command gate runs **after** Slice 4's one-time excluded-format cleanup,
with no unnecessary Office/PDF/OCR positive tests, dependencies or fixtures left as release
requirements. S3-VERIFY is a focused intermediate gate and cannot pass this final gate.
The commands below retain their five operations; D24 selects the verified locked Markdown
runtime `.venv-d17` and a new unique receipt directory to protect historical evidence.
No P18-FINAL command runs during this preparation.

| Focused evidence | D24 effective required scope |
| --- | --- |
| P18-QUALITY | D17 Markdown syntax/fidelity/source/locator/child semantics; native vi/en/Hans/Hant; D20 adjudication only within its accepted D17 bounds. No OCR or Office/PDF positive requirement. |
| P18-SNAPSHOT-APP | Whole-file R integrity/approval/path/no-overwrite/cleanup/recovery checks unchanged; actual indexing inputs `.md` only. |
| P18-PUBLISH-PG | Actual D17 Python -> Java -> PG result admission, role negatives, atomicity/fences, full per-file outcomes, rollback/unknown-C and Slice 4 lifecycle/NO_CHANGE integration. |
| P18-OFFLINE-MODEL | Pinned model/tokenizer, finite dimensioned pgvector, GPU and bounded same-model CPU fallback; no required OCR artifacts/runtime. |
| P18-RESOURCES | Final representative Markdown pipeline system RAM and VRAM separately, CPU/time/temp disk, finite file/expanded-text/chunk/reference/transport limits and cancellation. |
| P18-REPORT | Applicable outcomes, selected/pending R and G, qualified currentness, lifecycle/NO_CHANGE, truthful measured fallback/resources and recovery. |

This table supersedes only conflicting format-specific descriptions in the older table below.
The historical failed Java gate, D14's bounded exception, aggregate connection-resource investigation,
independent FR18-3 closure, remaining lifecycle/verification requirements and strict genuine-exit-zero
aggregation remain. No full success may be claimed by blanket skips or missing mandatory coverage.

## Preserved pre-D24 status and contract history

**D21 CURRENT — 2026-10-20: Slice 2 `.md` ONLY / `READY_FOR_INDEPENDENT_SLICE_2_CLOSEOUT_REVIEW`.** All twelve frozen D17 requirements remain mandatory and independently VERIFIED / accepted under D20. TXT, DOCX, PDF, XLS, XLSX and OCR are excluded from Slice 2 acceptance; historical code/tests/failures remain intact and reintroduction requires a future explicit Owner Decision. See [D21](owner-decisions.md#2026-10-20--d21-slice-2-obsidian-markdown-only-scope-rebase), the [controlling scope/matrix](slice-2-markdown-only-d21-scope-and-acceptance.md) and [proposed closeout](slice-2-markdown-only-d21-proposed-closeout-2026-10-20.md). **Slice 2 is not declared CLOSED and owner commit readiness is not granted here.** Phase 17 FROZEN; Slice 1/D14 CLOSED; FR18-3 OPEN; external indexing INACTIVE; historical Java full gate FAILED; Slices 3/4 unauthorized. No global Phase 18 acceptance or new implementation/activation.

## Preserved prior scope/status and broader target records

**D20 CURRENT — 2026-10-20: `D17_MARKDOWN_VERIFIED_ACCEPTED` (bounded, Codex-independent verification).** The Owner expressly replaces the previously required 213 case + 12 profile human-adjudication signoffs with the existing independent Codex final-review evidence **for D17 static Obsidian Markdown only**. All MD17-01–12 are `VERIFIED` within their reviewed producer-local and resource bounds; D17-R01–R05 and FR-01/02 remain independently `CLOSED`. This is an **explicit prospective Owner change of the quality acceptance gate**, not 225 fabricated human `ACCEPT` entries: the D19 human package remains untouched, unsigned and historically PENDING, and is **NOT_REQUIRED_UNDER_D20** for this bounded acceptance. See [D20](owner-decisions.md#2026-10-20--d20-d17-codex-independent-review-accepted-in-lieu-of-human-adjudication) and the [independent R03 review](reviews/2026-10-20-d17-r03-independent-final-re-review.md). **No original broader Slice 2, Java/FR18-3, P18-FINAL or Phase 18 acceptance; no external indexing or live-file activation, Slice 3/4 authorization, or automatic owner-commit readiness.** Phase 17 FROZEN; Slice 1/D14 CLOSED; FR18-3 OPEN; OCR/Office/PDF deferred; historical aggregate Java clean gate **FAILED**.

## Historical D19 and earlier snapshots (superseded for D17 by D20)

**D19 CURRENT — 2026-10-20: `HUMAN_REVIEW_PENDING`.** All MD17-01–12 executable machine gates are independently VERIFIED and D17-R01–R05 independently CLOSED under the R03 final re-review. Genuine human adjudication remains **required and unsigned**. D17 final acceptance and owner commit readiness are **NOT GRANTED**; original broader Slice 2 and Phase 18 remain unaccepted. See [D19](owner-decisions.md#2026-10-20--d19-d17-machine-disposition-and-human-adjudication-preparation), the [human package](d17-human-adjudication-2026-10-20/README.md) (213 cases + 12 profile confirmations, all pending), and [preparation evidence](d17-human-adjudication-preparation-evidence-2026-10-20.json). Next gate: actual human inspection and returned signed judgments, followed by reconciliation; no implementation or automatic acceptance. Phase 17 FROZEN; Slice 1/D14 CLOSED; FR18-3 OPEN; external indexing INACTIVE; live originals DISABLED/DEFERRED; other formats deferred; Slices 3/4 unauthorized. Historical Java full gate FAILED and preserved. No commit/push/tag or publication.

## Preserved prior gate/status records

**D17 COMPLETION CURRENT — 2026-10-20: `BLOCKED / OWNER_DECISION_REQUIRED`.** The finite completion checkpoint fixes inert HTML and separates the Python 3.14.4 Markdown runtime from deferred OCR. Final producer corpus: 1,266 structural/source passes plus 63 required whole-document rejections. D17/domain regressions: 128 passed; extra compatibility selection: 25 passed / 30 deferred-format cases deselected. **MD17-11 remains FAILED:** the 1,000,000-character workload exceeded the unchanged 60-second deadline twice; global temporary IO attribution is also unproven. Genuine human/independent quality review remains pending. See the [corrective handback](slice-2-obsidian-markdown-d17-corrective-handback-2026-10-20.md) and [current matrix](obsidian-markdown-d17-contract.md). No full-profile readiness or broader Slice 2 completion. Phase 17 FROZEN; Slice 1/D14 CLOSED; FR18-3 OPEN; external indexing INACTIVE; OCR/PDF/DOCX/XLS/XLSX acceptance deferred; Slices 3/4 unauthorized. Stop for independent review/owner disposition. No commit/push or automatic cycle.

## Preserved preceding checkpoint — historical

**D17 CURRENT - 2026-10-20: `BLOCKED / OWNER_DECISION_REQUIRED`, Markdown only.** The [frozen profile/matrix](obsidian-markdown-d17-contract.md) remains mandatory. The [dated implementation handback](slice-2-obsidian-markdown-d17-handback-2026-10-20.md) records structural source extraction, regression/producer evidence and remaining failures: HTML spanning blank blocks or using optional closing tags is rejected; the mandatory HTML gate is FAILED. The installed RapidOCR/Python version check also FAILS. No full-profile readiness or broader Slice 2 completion. OCR experiments STOPPED; OCR/PDF/DOCX/XLS/XLSX acceptance DEFERRED with code/tests/evidence preserved. Phase 17 FROZEN; Slice 1/D14 CLOSED; FR18-3 OPEN; external indexing INACTIVE; Slices 3-4 unauthorized. Stop for independent review/owner disposition. No commit/push or automatic remediation round.

## Preserved preceding scope/status - historical where superseded by D17

**Current D16 scope - 2026-10-20:** mandatory Slice 2 OCR is **Vietnamese (`vi`) and English (`en`)**; Chinese OCR is no longer required. Native Chinese text parsing/embedding scope is unchanged. [D16](owner-decisions.md#2026-10-20--d16-slice-2-vietnameseenglish-ocr-and-official-runtime-feasibility) authorizes a finite official PaddleOCR runtime feasibility investigation in an isolated venv; production pins/artifacts remain unchanged. Historical four-script failures below remain evidence, not current mandatory OCR denominators. Human adjudication, material completeness, reading order, table/box locators and all other quality/resource gates remain mandatory. See the [D16 handback](slice-2-d16-paddleocr-checkpoint-2026-10-20.md). **Status: BLOCKED / OWNER_DECISION_REQUIRED.** Three official-runtime candidates failed vi fidelity; no acceptance or Java identity alignment. Phase 17 FROZEN; Slice 1/D14 preserved; FR18-3 OPEN; external indexing INACTIVE; Slices 3-4 unauthorized.

# P18-FINAL — One integration gate for current Phase 18 contract

**Status:** Future execution **NOT RUN / NOT ACCEPTED**. Contract: [ADR-0023](../../adr/0023-phase-18-application-level-snapshot-worker-trust.md) + [acceptance](acceptance-and-evidence.md), effective 2026-10-19. The old native-ABA/Restricted Token/DACL/worker-denying ACL acceptance has been **removed** for external snapshots; this does **not** close functional, output-verification or lifecycle defects. Snapshot ingestion inactive. Historical strict-gate reviews are preserved unchanged.

## Carried obligations from the 2026-10-20 Slice 1 owner exception

[D14 / S1-RR-01](owner-decisions.md#2026-10-20--d14-p18-s1-verification-gate-exception-s1-rr-01) accepts the independently verified Slice 1 findings closure despite its failed aggregate clean gate; **it does not waive or pass P18-FINAL**. The [independent final acceptance](reviews/2026-10-20-slice-1-import-snapshot-independent-final-acceptance.md) verifies D14 and records `READY_FOR_OWNER_COMMIT` for Slice 1 only; S1-RR-01 is resolved by that exception. The retained gate remains **FAILED: 1,433 tests / 1 failure / 2 errors / 0 skips, exit 1**, with original evidence preserved in [test evidence](test-evidence.md) and the unchanged [independent re-review](reviews/2026-10-20-slice-1-import-snapshot-independent-re-review.md). No tests were rerun for the final acceptance.

- **Before P18-FINAL:** require bounded aggregate PostgreSQL connection-resource investigation and repeat verification. Connection-slot exhaustion in the aggregate run remains unresolved; focused **25/25** worker-boundary success does not establish full-suite stability. Retain the investigation scope, exact commands/receipts, resource observations, repeated aggregate result and unresolved limits for independent review. No root cause is assumed and no investigation, rerun or code/test change is authorized by this documentation update.
- **Future separately authorized Slice 3 / FR18-3:** verify the retained native document batch invalid-provenance failure against actual producer/publication requirements. The failure and **FR18-3 remain OPEN**, not resolved by this exception; preserve that evidence through final adjudication.
- **ADR-0023 scope:** the native alias test is excluded from Slice 1 acceptance, with its failure retained. This is supersession of that obligation, not a new PASS or authorization to weaken tests/global skill policies.

The five-command gate below and all retained quality/resource/producer obligations remain mandatory. No Slices 2–4 implementation, capability activation, FR18-3/P18-FINAL/Phase 18 closure or commit/push follows from this note.

## Exact existing Windows runner and five final commands (retained)

Run from repository root using **actual verified installed pinned** `rag-engine/.venv-d17/Scripts/python.exe`, `scripts/run-bounded-command.py`, Maven/Java and appropriate PostgreSQL/Testcontainers. Verify current code/environment before use. Missing interpreter/runner/test, nonzero exit, timeout or skipped required coverage is **FAIL**, not automatic PASS. The CLI watchdog is not a user indexing-time limit.

```powershell
$Root = (Get-Location).Path # must be the repository root
$Python = Join-Path $Root 'rag-engine/.venv-d17/Scripts/python.exe'
$Runner = Join-Path $Root 'scripts/run-bounded-command.py'
$Receipts = Join-Path $Root ('logs/phase18/p18-final-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $Receipts | Out-Null
if (-not (Test-Path $Python)) { throw 'Pinned worker Python venv missing; verify the locked environment' }
if (-not (Test-Path $Runner)) { throw 'Bounded runner missing' }

# Python: run exactly from rag-engine so ruff/pytest/pyproject settings apply.
Push-Location (Join-Path $Root 'rag-engine')
try {
  & $Python $Runner --receipt (Join-Path $Receipts 'ruff-check.json') -- $Python -m ruff check .
  if ($LASTEXITCODE -ne 0) { throw 'P18-FINAL: ruff check failed' }
  & $Python $Runner --receipt (Join-Path $Receipts 'ruff-format.json') -- $Python -m ruff format --check .
  if ($LASTEXITCODE -ne 0) { throw 'P18-FINAL: ruff format failed' }
  & $Python $Runner --receipt (Join-Path $Receipts 'mypy.json') -- $Python -m mypy src/ppv_rag
  if ($LASTEXITCODE -ne 0) { throw 'P18-FINAL: mypy failed' }
  & $Python $Runner --receipt (Join-Path $Receipts 'pytest.json') -- $Python -m pytest -q
  if ($LASTEXITCODE -ne 0) { throw 'P18-FINAL: pytest failed' }
} finally { Pop-Location }

# Java: full integration gate, extended profile ONLY for actual full clean verify.
& $Python $Runner --profile full-suite --receipt (Join-Path $Receipts 'full-java.json') -- mvn.cmd -ntp -f backend/pom.xml '-DargLine=--enable-native-access=ALL-UNNAMED' clean verify
if ($LASTEXITCODE -ne 0) { throw 'P18-FINAL: full Java clean verify failed' }
```

The existing normal command cap is 1,200 s; genuine Maven full-suite may use 2,100 s when supported. Extended pytest profile only if permitted by current runner's full-suite checks; do not silently alter this preserved executable list. Commands require a separately authorized implementation/acceptance run.

## Linked **minimal focused evidence** (develop earlier; no duplicated final suites)

| Receipt | Concrete required result |
| --- | --- |
| `P18-QUALITY` | Representative sanitized source-grouped dev/held-out TXT/MD/Obsidian/DOCX/PDF native+scan+mixed/XLSX/XLS; vi/en OCR under D16 plus retained native vi/en/zh-Hans/zh-Hant coverage, reading/table/merged/hidden material, exact mandatory locators. Counts for all failures/skips/pending and original unchanged. |
| `P18-SNAPSHOT-APP` | Explicit whole-file grant, practical regular-path/reparse/size validation, exact copy SHA-256+length and before/after detectable-change checks; no-clobber R/manifest, check on reuse, same/different-byte/NO_CHANGE, revoke/tamper/missing/disk-full/cancel/restart/orphan/cleanup. **No Restricted Token, per-attempt DACL, NTFS ABA/hard-link/mapping/writer attack proof or forensic durability certificate.** |
| `P18-PUBLISH-PG` | Real Python-produced/staged text/chunks/locators/model/vector and trusted Java verification of actual result (FR18-3); PostgreSQL `rag_worker` SQL grant negatives, source-first guards, full union and own-G closure, mixed 8-success/2-fail, all-fail/cancel, changed/unchanged, child changes, rollback, genuine unknown-C and exactly one final physical publication transaction or none. |
| `P18-OFFLINE-MODEL` | Installed model/OCR artifacts pinned, no required runtime API/network pull, actual finite pgvector rows, native GPU and **same model** bounded CPU fallback, failed-resource cases. |
| `P18-RESOURCES` | Actual representative 16 GB system RAM usage and 8 GB VRAM **measured separately**, CPU/wall/temp disk, upper limits for file/page/row/chunks/expanded data, cancellation and safe work cleanup. No fabricated limits. |
| `P18-REPORT` | Individual file failures/successes and warnings, selected/pending R, NO_CHANGE/retained vs new G, qualified SNAPSHOT_CURRENT and original UNVERIFIED, measured GPU fallback, controlled purge/unknown backups and truthful recovery status. |

## Aggregation

Require five commands' genuine exit `0`, accurate counts and receipts, and independent review of **the focused cases above**. Record OS/hardware, model/fixture/version hashes, measured RAM/VRAM, unresolved issues and retest disposition. No private source contents/paths/credentials in reports. No extra C_D/C_N forensic-proof matrix; maintain actual race/SQL/unknown-outcome correctness and working Phase 17 fences. Do not claim universal power-loss durability from ordinary filesystem APIs.

A full-suite failure including `AUTH-CLOCK`, missing model/library or unrun focused case is not PASS; record cause for an explicit later owner decision. G1–G4 and FR18-1–11 are not closed here. No automatic code execution, commit/push or capability activation is authorized by editing these docs.
