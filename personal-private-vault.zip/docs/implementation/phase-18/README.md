## D26 prospective CPU-only applicability - 2026-10-25

**OWNER_APPROVED scope amendment; final acceptance NOT GRANTED.** [D26](owner-decisions.md#d26-cpu-only)
selects pinned offline CPU inference ONLY. Actual CUDA inference, GPU OOM-to-CPU fallback
and process-attributed GPU VRAM remain **NOT VERIFIED** and are
**NOT_APPLICABLE_UNDER_OWNER_APPROVED_CPU_ONLY_SCOPE**, never PASS. See the
[exact execution profile and reconciliation](cpu-only-d26-applicability-2026-10-25.md).

**Current evidence routing:** the independent final corrective re-review found no non-GPU mandatory blocker and audited all five source-applicable command PASS receipts. D26 approves option B execution applicability; prior GPU_EVIDENCE_BLOCKED records below retain their original truth. See the [D26 documentation handback](slice-4-cpu-only-d26-handback-2026-10-25.md) for exact preservation/source/receipt checks. Independent CPU-only final review and explicit Owner closeout remain pending; this is not Phase 18 acceptance.

This is prospective acceptance applicability only. Unaffected Markdown/authority/publication,
CPU/RAM/disk/deadline/cancellation/security and five-command requirements remain mandatory.
Future GPU enablement requires separate Owner authorization and independent verification.
No source/runtime/test/model/lock/runner change, activation or closeout follows. Original
GPU_EVIDENCE_BLOCKED and failed/timeout evidence remains unchanged historical truth.
Slice 4/P18-FINAL/Phase 18 remain NOT ACCEPTED / NOT CLOSED; indexing INACTIVE.

## Preserved pre-D26 text - unaffected rules remain effective

> **Final count qualification:** current Maven stdout1580/1/0/1; fresh XML1567/1/0/1, difference13 UNEXPLAINED. Exit1/FAILED; no P18-FINAL acceptance. See the corrective handback for both current and historical counts.

> **Corrective handback - 2026-10-24:** `BLOCKED / GPU_EVIDENCE_BLOCKED`. See [handback](slice-4-codex-corrective-handback-2026-10-24.md) and [S4 matrix](slice-4-codex-corrective-matrix-2026-10-24.md). Native 104 and Python 238 pass; actual full Java exit 1 ({'tests': 1567, 'failures': 1, 'errors': 0, 'skipped': 1}). CUDA inference/fallback remains unavailable and unwaived. Slice 4/P18-FINAL NOT ACCEPTED. Earlier dated results/statuses below are preserved history.

> **Current S4 routing ? 2026-10-23:** Codex has issued [the executable Lifecycle & Final handoff](slice-4-executable-handoff-2026-10-23.md) with [all S4 test mappings](slice-4-execution-and-test-plan-2026-10-23.md); [ACTIVE](../handoffs/ACTIVE.md) is `READY_FOR_IMPLEMENTATION`. This is preparation only: implementation NOT_STARTED, all S4 rows NOT_RUN, P18-FINAL NOT ACCEPTED, indexing INACTIVE. Earlier pending notices below describe prior states.

**CURRENT OWNER STATUS — D25 / 2026-10-23:** Phase 18 **Slice 3 Verified Indexing D+F is COMPLETE / CLOSED / OWNER-PUBLISHED** at verified GitHub `main` commit `e2e00534fb35534a298e8fb15d174f18cb63b5a0` (90/90 reviewed paths). S3-F01–F06, S3-RR-01–03 and **FR18-3 are independently VERIFIED/CLOSED** within D24's Obsidian `.md` producer → Java → PostgreSQL publication scope. Owner has authorized **Slice 4 Lifecycle & Final (E+H)**; canonical [ACTIVE](../handoffs/ACTIVE.md) now records `P18-S4-LIFECYCLE-FINAL / PENDING_CODEX_HANDOFF`. Refer to [D25](owner-decisions.md#2026-10-23--d25-slice-3-owner-published-closeout-and-slice-4-authorization), [Slice 3 closeout](slice-3-closeout-2026-10-23.md), [Slice 4 preparation](slice-4-lifecycle-final-handoff-2026-10-23.md) and [S4 matrix](slice-4-lifecycle-final-acceptance-2026-10-23.md). External indexing **INACTIVE**; live originals **DISABLED/DEFERRED**; Phase 18/P18-FINAL **NOT ACCEPTED**; historical Java full gate **FAILED**; D22 originals **NOT_RECOVERED**. Consolidated removal of unaccepted TXT/`.markdown`/PDF/Office/OCR implementation is planned **once near Slice 4 end before P18-FINAL**; historical applied Flyway migrations and failure evidence remain intact. The D24 and older status statements below are **dated historical records and do not override D25**.

---

**D24 CURRENT - 2026-10-21:** Overall Phase 18 external document target is **Obsidian Markdown `.md` ONLY**. Owner authorizes the new initial **Slice 3 Verified Indexing D+F**; see [D24](owner-decisions.md#2026-10-21--d24-overall-markdown-only-phase-18-and-slice-3-verified-indexing), [executable handoff](slice-3-verified-indexing-handoff.md), [baseline/applicability/cleanup](slice-3-markdown-scope-and-baseline-2026-10-21.md). Slice 2/D23 producer-local scope is CLOSED and prior work is **published** at verified main `ef32d41b33dd00e5fa08cf63977e91b8936ef3d5`, including unaccepted mixed changes; publication does not accept them. The former selective staging/commit workflow is superseded and must not be reopened. TXT/Office/PDF/OCR are excluded from Slice 3 and final Markdown acceptance; temporarily retain without use/certification, then remove unnecessary implementation/dependencies/tests/fixtures once at Slice 4 end before P18-FINAL. No Slice 4 implementation now. Phase 17 FROZEN; Slice 1/D14 CLOSED; D22 originals NOT_RECOVERED / original preservation FAILED; FR18-3 OPEN; Java publication NOT ACCEPTED; historical full Java gate FAILED until genuine successful rerun; indexing INACTIVE; live originals DISABLED/DEFERRED; P18-FINAL NOT ACCEPTED. Historical Antigravity remediation 2/2 remains exhausted; this initial slice grants no extra remediation rounds. Preparation only in this session; no activation or agent publishing.

## RR-01-03 corrective checkpoint - 2026-10-22

The separately Owner-authorized RR-01-03 checkpoint returns **READY_FOR_INDEPENDENT_SLICE_3_RE_REVIEW**. Final Java selections pass 249/0/0/0 on identical source; Python passes 198 tests. This is implementation evidence awaiting independent review.
Its [new handback](slice-3-rr-corrective-handback-2026-10-22.md),
[executed matrix](slice-3-rr-corrective-matrix-2026-10-22.md) and
[machine inventory](slice-3-rr-corrective-evidence-2026-10-22.json) record original
counterexamples, minimal corrections and preserved failures. Earlier submitted
readiness claims are historical; the independent CHANGES_REQUESTED review is
preserved. FR18-3 OPEN; external indexing INACTIVE; no Slice 3 acceptance,
activation, publishing or Slice 4 authorization.


## Additional final Slice 3 checkpoint - 2026-10-22

The Owner authorized one finite continuation for remaining S3-F03/S3-F06 and
mandatory Slice 3 evidence. **READY_FOR_INDEPENDENT_SLICE_3_RE_REVIEW**. Final selected Java 238/0/0/0, Python 189 and required static/corpus checks pass. See the
[new handback](slice-3-final-corrective-handback-2026-10-22.md),
[executed matrix](slice-3-final-corrective-matrix-2026-10-22.md) and
[machine inventory](slice-3-final-corrective-evidence-2026-10-22.json).
Codex is the implementer; independent review remains required. Prior failed
receipts/reviews and BLOCKED checkpoint are preserved, with no Antigravity reset,
Slice 3/FR18-3 closure, activation, publishing, Slice 4 or automatic further checkpoint.

## Preserved prior Slice 3 corrective checkpoint — 2026-10-21

**BLOCKED.** One separately owner-authorized Codex checkpoint corrected the
reviewed trust/authority/transport paths and added native regressions, but full
S3-F03 target resolution and the mandatory S3-F06 evidence remain incomplete.
See the [corrective handback](slice-3-codex-corrective-handback-2026-10-21.md),
[executed matrix](slice-3-codex-corrective-matrix-2026-10-21.md) and
[machine evidence](slice-3-codex-corrective-evidence-2026-10-21.json).
The 178-test Java selection, 3 read-order checks and 4 final revision-binding checks are bounded passing
evidence; they do not close FR18-3 or replace the failed historical full gate.
No activation, Slice 4, publishing or automatic further checkpoint is authorized.

## Preserved pre-D24 status and contract history

**D23 CURRENT — 2026-10-21: D21 Markdown-only Slice 2 producer-local scope CLOSED by Owner, NOT YET OWNER-PUBLISHED.** Based on the [independent final closeout review](reviews/2026-10-21-slice-2-d22-01-independent-final-closeout-re-review.md), all MD17-01–12 remain VERIFIED and S2-D22-01 is CLOSED. See [D23](owner-decisions.md#2026-10-21--d23-bounded-phase-18-slice-2-markdown-only-owner-closeout) and the [bounded closeout](slice-2-markdown-only-d23-closeout-2026-10-21.md). Delivery is NOT READY_FOR_OWNER_COMMIT until exact hunk-level staging of the reviewed 34-change source candidate and independently verified docs scope; no bulk staging. D22 original captures remain NOT_RECOVERED. ADR-0024 accepted only for this slice. FR18-3 OPEN, indexing INACTIVE, Java publication and P18-FINAL NOT ACCEPTED, original Java gate FAILED, Slices 3/4 unauthorized.

**D22 current status — 2026-10-21: `READY_FOR_INDEPENDENT_CLOSEOUT_RE_REVIEW`, not Slice 2 CLOSED.** Owner [D22](owner-decisions.md#2026-10-21--d22-bounded-s2-d21-e01-evidence-disposition-and-adr-0024-adoption) accepted the explicitly recorded three-raw-JSON evidence gap without restoring missing historical bytes, and [ADR-0024](../../adr/0024-phase-18-slice-profile-acceptance-boundaries.md) is ACCEPTED prospectively for D21 Slice 2 scope only. The independent October 21 `CHANGES_REQUESTED` result stays historical; a separate [re-review](slice-2-markdown-only-d22-closeout-rereview-handoff-2026-10-21.md) is required. No owner commit/closeout or broader Phase 18 acceptance.

**D21 CURRENT — 2026-10-20: Slice 2 `.md` ONLY / `READY_FOR_INDEPENDENT_SLICE_2_CLOSEOUT_REVIEW`.** All twelve frozen D17 requirements remain mandatory and independently VERIFIED / accepted under D20. TXT, DOCX, PDF, XLS, XLSX and OCR are excluded from Slice 2 acceptance; historical code/tests/failures remain intact and reintroduction requires a future explicit Owner Decision. See [D21](owner-decisions.md#2026-10-20--d21-slice-2-obsidian-markdown-only-scope-rebase), the [controlling scope/matrix](slice-2-markdown-only-d21-scope-and-acceptance.md) and [proposed closeout](slice-2-markdown-only-d21-proposed-closeout-2026-10-20.md). **Slice 2 is not declared CLOSED and owner commit readiness is not granted here.** Phase 17 FROZEN; Slice 1/D14 CLOSED; FR18-3 OPEN; external indexing INACTIVE; historical Java full gate FAILED; Slices 3/4 unauthorized. No global Phase 18 acceptance or new implementation/activation.

## Preserved prior scope/status and broader target records

**D20 CURRENT — 2026-10-20: `D17_MARKDOWN_VERIFIED_ACCEPTED` (bounded, Codex-independent verification).** The Owner expressly replaces the previously required 213 case + 12 profile human-adjudication signoffs with the existing independent Codex final-review evidence **for D17 static Obsidian Markdown only**. All MD17-01–12 are `VERIFIED` within their reviewed producer-local and resource bounds; D17-R01–R05 and FR-01/02 remain independently `CLOSED`. This is an **explicit prospective Owner change of the quality acceptance gate**, not 225 fabricated human `ACCEPT` entries: the D19 human package remains untouched, unsigned and historically PENDING, and is **NOT_REQUIRED_UNDER_D20** for this bounded acceptance. See [D20](owner-decisions.md#2026-10-20--d20-d17-codex-independent-review-accepted-in-lieu-of-human-adjudication) and the [independent R03 review](reviews/2026-10-20-d17-r03-independent-final-re-review.md). **No original broader Slice 2, Java/FR18-3, P18-FINAL or Phase 18 acceptance; no external indexing or live-file activation, Slice 3/4 authorization, or automatic owner-commit readiness.** Phase 17 FROZEN; Slice 1/D14 CLOSED; FR18-3 OPEN; OCR/Office/PDF deferred; historical aggregate Java clean gate **FAILED**.

## Historical D19 and earlier snapshots (superseded for D17 by D20)

**D19 CURRENT — 2026-10-20: `HUMAN_REVIEW_PENDING`.** All MD17-01–12 executable machine gates are independently VERIFIED and D17-R01–R05 independently CLOSED under the R03 final re-review. Genuine human adjudication remains **required and unsigned**. D17 final acceptance and owner commit readiness are **NOT GRANTED**; original broader Slice 2 and Phase 18 remain unaccepted. See [D19](owner-decisions.md#2026-10-20--d19-d17-machine-disposition-and-human-adjudication-preparation), the [human package](d17-human-adjudication-2026-10-20/README.md) (213 cases + 12 profile confirmations, all pending), and [preparation evidence](d17-human-adjudication-preparation-evidence-2026-10-20.json). Next gate: actual human inspection and returned signed judgments, followed by reconciliation; no implementation or automatic acceptance. Phase 17 FROZEN; Slice 1/D14 CLOSED; FR18-3 OPEN; external indexing INACTIVE; live originals DISABLED/DEFERRED; other formats deferred; Slices 3/4 unauthorized. Historical Java full gate FAILED and preserved. No commit/push/tag or publication.

## Preserved prior gate/status records

**D17 COMPLETION CURRENT — 2026-10-20: `BLOCKED / OWNER_DECISION_REQUIRED`.** The finite completion checkpoint fixes inert HTML and separates the Python 3.14.4 Markdown runtime from deferred OCR. Final producer corpus: 1,266 structural/source passes plus 63 required whole-document rejections. D17/domain regressions: 128 passed; extra compatibility selection: 25 passed / 30 deferred-format cases deselected. **MD17-11 remains FAILED:** the 1,000,000-character workload exceeded the unchanged 60-second deadline twice; global temporary IO attribution is also unproven. Genuine human/independent quality review remains pending. See the [corrective handback](slice-2-obsidian-markdown-d17-corrective-handback-2026-10-20.md) and [current matrix](obsidian-markdown-d17-contract.md). No full-profile readiness or broader Slice 2 completion. Phase 17 FROZEN; Slice 1/D14 CLOSED; FR18-3 OPEN; external indexing INACTIVE; OCR/PDF/DOCX/XLS/XLSX acceptance deferred; Slices 3/4 unauthorized. Stop for independent review/owner disposition. No commit/push or automatic cycle.

## Preserved preceding checkpoint — historical

**D17 CURRENT - 2026-10-20: `BLOCKED / OWNER_DECISION_REQUIRED`, Markdown only.** The [frozen profile/matrix](obsidian-markdown-d17-contract.md) remains mandatory. The [dated implementation handback](slice-2-obsidian-markdown-d17-handback-2026-10-20.md) records structural source extraction, regression/producer evidence and remaining failures: HTML spanning blank blocks or using optional closing tags is rejected; the mandatory HTML gate is FAILED. The installed RapidOCR/Python version check also FAILS. No full-profile readiness or broader Slice 2 completion. OCR experiments STOPPED; OCR/PDF/DOCX/XLS/XLSX acceptance DEFERRED with code/tests/evidence preserved. Phase 17 FROZEN; Slice 1/D14 CLOSED; FR18-3 OPEN; external indexing INACTIVE; Slices 3-4 unauthorized. Stop for independent review/owner disposition. No commit/push or automatic remediation round.

## Preserved preceding scope/status - historical where superseded by D17

**Latest D16 Tesseract/VietOCR checkpoint - 2026-10-20: `BLOCKED / OWNER_DECISION_REQUIRED`.** The owner authorized one new finite feasibility/heading-repair checkpoint, not another automatic remediation round. Tesseract 5.5.3 (three configurations) is 5/6 exact exposed development files with a Vietnamese tone substitution; both VietOCR architectures also fail. The PDF parser now OCRs the measured-cell-masked image remainder, retaining headings, side notes and footers; two real-PDF regressions and all 119 Python tests pass. No verified model promoted, production dependency changed, human approval claimed, selected-backend S2-07 proof or S2-08 Java alignment performed. See the [new handback](slice-2-tesseract-vietocr-checkpoint-2026-10-20.md). Phase 17 FROZEN; Slice 1/D14 preserved; FR18-3 OPEN; external indexing INACTIVE; Slices 3-4 unauthorized. The historical full Java gate remains FAILED. Stop for independent review/owner disposition; no commit/push or automatic continuation.

## Preserved preceding checkpoint - historical

**Current D16 scope - 2026-10-20:** mandatory Slice 2 OCR is **Vietnamese (`vi`) and English (`en`)**; Chinese OCR is no longer required. Native Chinese text parsing/embedding scope is unchanged. [D16](owner-decisions.md#2026-10-20--d16-slice-2-vietnameseenglish-ocr-and-official-runtime-feasibility) authorizes a finite official PaddleOCR runtime feasibility investigation in an isolated venv; production pins/artifacts remain unchanged. Historical four-script failures below remain evidence, not current mandatory OCR denominators. Human adjudication, material completeness, reading order, table/box locators and all other quality/resource gates remain mandatory. See the [D16 handback](slice-2-d16-paddleocr-checkpoint-2026-10-20.md). **Status: BLOCKED / OWNER_DECISION_REQUIRED.** Three official-runtime candidates failed vi fidelity; no acceptance or Java identity alignment. Phase 17 FROZEN; Slice 1/D14 preserved; FR18-3 OPEN; external indexing INACTIVE; Slices 3-4 unauthorized.

**Corrective takeover status - 2026-10-20:** `P18-S2-PARSER-OCR-EMBEDDING / BLOCKED / OWNER_DECISION_REQUIRED`. One separately owner-authorized Codex corrective scope addressed S2-01 through S2-08; it does not reset historical Antigravity 2/2. Deterministic repairs are tested, but four-script OCR/fresh human-adjudicated held-out quality (S2-06), complete native parsing interruption/resource proof (S2-07), and the Java pipeline-identity compatibility gate (S2-08) remain unresolved. See [corrective handback](slice-2-parser-ocr-embedding-codex-corrective-handback-2026-10-20.md). Phase 17 remains FROZEN; Slice 1 COMPLETE/CLOSED under D14; FR18-3 OPEN; external indexing INACTIVE, live originals DISABLED/DEFERRED; Slices 3-4 unauthorized. No Slice 2 acceptance, automatic further implementation or agent publishing. Earlier dated statuses are historical where inconsistent.

# Phase 18 — Document ingestion, OCR, embedding and verified indexing

**Current state after owner implementation commit (2026-10-20):** [Slice 1 Import & Snapshot formal closeout](slice-1-closeout.md) records **COMPLETE / CLOSED / OWNER-PUBLISHED under D14**, commit [`7e1a4cd`](https://github.com/vhvkhangg/personal-private-vault/commit/7e1a4cd34fbe19f8162150945534e9509093b3f5). [ACTIVE](../handoffs/ACTIVE.md) is now `NO_ACTIVE_HANDOFF`; the [Slice 1 handoff](slice-1-import-snapshot-handoff.md) is archived. Seven S1 findings closed on independently inspected implementation and **210/0/0/0** focused tests; **full clean gate still FAILED (1,433 / 1 failure / 2 errors / 0 skips)**. Producer provenance/FR18-3 and aggregate PG resource verification remain OPEN under [D14](owner-decisions.md#2026-10-20--d14-p18-s1-verification-gate-exception-s1-rr-01). **Overall Phase 18 is NOT ACCEPTED; external indexing INACTIVE; Slices 2–4 NOT AUTHORIZED.** The next implementation slice requires a new owner gate. Closeout docs still await a separate owner commit/push.

**Pre-closeout owner contract and handoff (historical, 2026-10-20):** [ADR-0023](../../adr/0023-phase-18-application-level-snapshot-worker-trust.md) amends [ADR-0022](../../adr/0022-phase-18-immutable-snapshot-whole-file-consent-no-change.md); D12/D13 govern application-level G1/G3 and bounded Slice 1. [D14](owner-decisions.md#2026-10-20--d14-p18-s1-verification-gate-exception-s1-rr-01) records the owner's single **S1-RR-01 verification-gate exception**, independently verified by the [final Slice 1 acceptance](reviews/2026-10-20-slice-1-import-snapshot-independent-final-acceptance.md): **S1-01–S1-07 remain CLOSED; S1-RR-01 is RESOLVED BY OWNER EXCEPTION D14**. [P18-S1-IMPORT-SNAPSHOT](slice-1-import-snapshot-handoff.md) and [ACTIVE](../handoffs/ACTIVE.md) are `READY_FOR_OWNER_COMMIT` for Slice 1 only, based on the original **210 focused tests / 0 failures / 0 errors / 0 skips** and unchanged reviewed implementation. The aggregate clean gate remains **FAILED: 1,433 tests / 1 failure / 2 errors / 0 skips, exit 1**; this final check ran no tests and does not make that gate PASS. Overall Phase 18 remains **INCOMPLETE / NOT ACCEPTED**; snapshot indexing `INACTIVE`, original-live indexing `DISABLED / DEFERRED`, Phase 17 frozen. No original FR18-1–11 or full G1–G4 closure is asserted; Slices 2–4 and P18-FINAL acceptance remain unauthorized.

**Open verification obligations:** native alias failure is excluded from Slice 1 acceptance under ADR-0023, with evidence preserved. Native document batch provenance failure remains **OPEN** for future separately authorized **Slice 3 verification of FR18-3**. Aggregate PostgreSQL connection-slot exhaustion remains unresolved; focused **25/25** worker-boundary success does not establish full-suite stability. Require **bounded aggregate resource investigation and repeat verification before P18-FINAL**. This documentation update launches no investigation, test or implementation work.

## Deliverable and boundaries

An explicit single-user import/update/reindex batch produces verified PostgreSQL/pgvector generations G for approved document snapshots R and reports success/failure **per file**. Java `rag` retains source/consent/revision/authorization, selected R, guards, worker lifecycle and **one final atomic publication transaction**. Python is the local parser/OCR/chunker/embed producer, under the same ordinary Windows user; it does not decide source authority or publish G. No RAG chat, retrieval, judge or recommendation scope here (Phases 19–22).

**Formats/semantics:** TXT; Markdown/Obsidian frontmatter/headings/tags/wikilinks/aliases/anchors/block links/callouts and individually approved transclusions; DOCX paragraphs, tables, supported hidden/comments/properties; PDF native/scanned/mixed with native-text-first selective OCR, reading order, tables and valid page/bounding boxes; XLSX/XLS sheets, rows, columns, merged/hidden cells, supported comments/metadata. Languages: vi, en, zh-Hans, zh-Hant. One structure-aware chunker, typed original locators including narrow non-page structural locator, one multilingual model, true finite pgvector embedding. No invented coordinates, silent exclusion of approved materially relevant content, document-code execution, remote fetch or source write-back.

**Workflow:** one explicit whole-file approval per external file; each independently opened child requires another. Original O, source S, exact-byte revision R and index generation G are distinct. Java makes finite copy, SHA-256/length, no-overwrite sealed R plus manifest, checks integrity on R use; application-level immutable, **not** same-user OS anti-tamper. Changed approved Update creates new R; qualified `NO_CHANGE` changes no R/sourceVersion/G/consent and skips worker; explicit same-R Reindex uses R. `SNAPSHOT_CURRENT` requires authorized selected R/G plus actual verified dependencies/integrity, `originalFreshness=UNVERIFIED`; original changes never trigger background imports. Revoke/integrity failure disables affected reads/updates and triggers bounded cleanup/reconciliation.

**Operation:** reuse Phase 17's one job/worker, exact source union, ordered source-first SQL guards, one-use grants, cancel, stop/drain/seal and unknown-commit recovery. Python results require **actual** text/chunk/locator/model/vector validation by trusted Java (`FR18-3` open), not just copied-file checksum. Independent file errors do not publish that file; good files publish as **one** C_P or none. Do not introduce a new state-machine/incident engine. Preserve real revocation race guards, atomic release and existing API compatibility.

**Runtime/quality:** local and offline (no required AI API/model fetch), controlled GPU and same-model CPU fallback, finite measured 16 GB system RAM / 8 GB GPU VRAM, CPU, wall time, temporary disk, file/page/row/chunk/expanded-content and cancellation/restart bounds. Benchmark with representative source-grouped fixtures for all formats/scripts, OCR/table reading and locators. Fail materially incomplete extraction; report truthful per-file outcomes, warnings, NO_CHANGE, retained/new generations, fallback, resource measurements and unresolved cleanup.

## Implementation units (not four new engines)

1. **Import & Snapshot (A+B+C):** reuse source/consent/reservations; ordinary safe capture, exact copy SHA-256, temp/no-overwrite R, selection and revision tracking. No native ABA/OS sandbox build.
2. **Parsing & Embedding (G+H):** TXT/MD/native PDF → Office/XLS/XLSX → scanned/mixed PDF OCR/layout → structure-first chunks, typed locators, multilingual vectors. Keep parser tests independent of DB where possible.
3. **Verified Indexing (D+F):** use existing worker/process/SQL roles/staging, verify *real* produced output, only trusted Java final C_P, mixed-file outcomes and exact revision closures. Preserve rollbacks, source lock order and unknown-commit recovery.
4. **Lifecycle & Final Tests (E+H):** qualified NO_CHANGE/reindex, revoke/delete, temp/orphan/restart/cleanup, resource caps and reporting, source-grouped held-out suite, one complete P18-FINAL.

## Historical pre-closeout status and canonical links

Historical A+B handbacks, CP18-AB-2 isolation reviews and Slice 1 reviews/handbacks **remain unchanged**. The complete [2026-10-20 independent re-review](reviews/2026-10-20-slice-1-import-snapshot-independent-re-review.md) closes the seven bounded S1 implementation findings; its remaining S1-RR-01 owner disposition is now recorded in D14. **Historical next gate (now satisfied):** independent final check of D14 was completed and owner implementation commit/push followed. No implementation resumption, new Antigravity round or automatic takeover follows; historical rounds remain **2/2 exhausted**. Slices 2–4 require separate authorization; no commit/push, FR18-3/P18-FINAL closure or Phase 18 acceptance is granted.

[Owner decisions](owner-decisions.md) · [Archived Slice 1 handoff](slice-1-import-snapshot-handoff.md) · [Simplified four-slice plan](simplified-implementation-handoff.md) · [Acceptance](acceptance-and-evidence.md) · [P18-FINAL](final-verification-gate.md) · [Current API/target](../../architecture/rag-phase-18-api-extension.md) · [Phase 18 logical DBML](../../database/phase-18-document-indexing.dbml). No new migration/schema claim or runtime PASS follows from docs alone.
